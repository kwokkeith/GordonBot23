# PS4ControllerESP32_Robot
Repositório com todos os itens necessários para programar um ESP32 para se conectar ao controle de PS4 e controlar um robô com locomoção estilo tanque.

O código e outras informações foram baseadas usando como referência o GitHub da Equeipe de Robótica Project Neon. Github: https://github.com/project-neon/combat/tree/master/src/cirrose

Mais detalhes de como usar esse código e como evitar alguns problemas, segue o link do vídeo no YouTube: https://youtu.be/hXP_kQ_EbkA
